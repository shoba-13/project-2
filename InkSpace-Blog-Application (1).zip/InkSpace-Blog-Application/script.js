/* InkSpace – demo front-end app. All data lives in this browser's localStorage. */
const $ = (s, r = document) => r.querySelector(s);
const store = {
  get(k, d) { try { const v = JSON.parse(localStorage.getItem(k)); return v ?? d; } catch { return d; } },
  set(k, v) { localStorage.setItem(k, JSON.stringify(v)); }
};
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmtDate = iso => new Date(iso).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
const page = document.body.dataset.page;

const getUsers = () => store.get('inkspace_users', []);
const getPosts = () => store.get('inkspace_posts', []);
const getUser = () => store.get('inkspace_session', null);

// First-run sample stories
if (!localStorage.getItem('inkspace_posts')) {
  store.set('inkspace_posts', [
    { id: 1, title: 'Why I started writing every morning', category: 'Life', author: 'Maya Iyer', email: 'sample@inkspace.dev', date: '2026-10-02T08:00:00Z', body: 'Ten minutes, one page, no editing. That was the rule.\n\nA month in, my mornings feel quieter and my ideas arrive in full sentences. If you have been meaning to start, start small.' },
    { id: 2, title: 'A beginner\'s map of the web stack', category: 'Technology', author: 'Arjun Das', email: 'sample@inkspace.dev', date: '2026-10-18T10:30:00Z', body: 'HTML gives a page its structure. CSS gives it a look. JavaScript gives it behaviour.\n\nLearn them in that order and build something small at every step.' },
    { id: 3, title: 'Tea gardens of the Nilgiris', category: 'Travel', author: 'Meera Nair', email: 'sample@inkspace.dev', date: '2026-11-05T06:15:00Z', body: 'The mist lifts around seven. By then the pickers are already halfway down the slope.\n\nBring a jacket, and leave time to just sit with a cup.' }
  ]);
}

function toast(msg) {
  const t = $('#toast'); if (!t) return;
  t.textContent = msg; t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2600);
}
const flash = msg => sessionStorage.setItem('inkspace_flash', msg);
const flashMsg = sessionStorage.getItem('inkspace_flash');
if (flashMsg) { sessionStorage.removeItem('inkspace_flash'); setTimeout(() => toast(flashMsg), 150); }

// Navigation
function renderNav() {
  const u = getUser();
  const cur = f => (location.pathname.endsWith(f) || (f === 'index.html' && /\/$/.test(location.pathname))) ? ' aria-current="page"' : '';
  $('#nav').innerHTML = `<a class="brand" href="index.html">🌿 InkSpace</a>
    <a href="index.html"${cur('index.html')}>Home</a>` + (u
    ? `<a href="dashboard.html"${cur('dashboard.html')}>Dashboard</a><a href="create-blog.html"${cur('create-blog.html')}>Write</a><button id="logout" type="button">Log out</button>`
    : `<a href="login.html"${cur('login.html')}>Log in</a><a class="cta" href="register.html">Register</a>`);
  const lo = $('#logout');
  if (lo) lo.onclick = () => { localStorage.removeItem('inkspace_session'); flash('You have been logged out.'); location.href = 'index.html'; };
}
renderNav();

// Protected pages
if ((page === 'dashboard' || page === 'create') && !getUser()) location.replace('login.html');
if ((page === 'login' || page === 'register') && getUser()) location.replace('dashboard.html');

const showError = m => { $('#formError').textContent = m; };
const validEmail = e => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);

// Register
if (page === 'register') $('#registerForm').addEventListener('submit', e => {
  e.preventDefault();
  const f = new FormData(e.target);
  const name = f.get('name').trim(), email = f.get('email').trim().toLowerCase(), pw = f.get('password');
  if (!name) return showError('Enter your full name.');
  if (!validEmail(email)) return showError('Enter a valid email address.');
  if (pw.length < 6) return showError('Password must be at least 6 characters.');
  if (pw !== f.get('confirm')) return showError('Passwords do not match.');
  const users = getUsers();
  if (users.some(u => u.email === email)) return showError('An account with this email already exists. Log in instead.');
  users.push({ name, email, password: pw }); // demo only: never store plain passwords in a real app
  store.set('inkspace_users', users);
  flash('Account created. Please log in.');
  location.href = 'login.html';
});

// Login
if (page === 'login') $('#loginForm').addEventListener('submit', e => {
  e.preventDefault();
  const f = new FormData(e.target);
  const email = f.get('email').trim().toLowerCase();
  const user = getUsers().find(u => u.email === email && u.password === f.get('password'));
  if (!user) return showError('Email or password is incorrect.');
  store.set('inkspace_session', { name: user.name, email: user.email });
  flash(`Welcome back, ${user.name.split(' ')[0]}!`);
  location.href = 'dashboard.html';
});

// Home
if (page === 'home') {
  const posts = getPosts().sort((a, b) => new Date(b.date) - new Date(a.date));
  $('#postGrid').innerHTML = posts.map(p => `<article class="post">
    <span class="tag">${esc(p.category)}</span><h3>${esc(p.title)}</h3>
    <p>${esc(p.body.slice(0, 120))}${p.body.length > 120 ? '…' : ''}</p>
    <span class="meta">${esc(p.author)} · ${fmtDate(p.date)}</span>
    <button class="btn ghost" data-id="${p.id}">Read story</button></article>`).join('');
  const dlg = $('#readDialog');
  $('#postGrid').addEventListener('click', e => {
    const id = e.target.dataset.id; if (!id) return;
    const p = posts.find(x => String(x.id) === id);
    $('#readBody').innerHTML = `<span class="tag post-tag">${esc(p.category)}</span><h1>${esc(p.title)}</h1>
      <p class="meta muted">${esc(p.author)} · ${fmtDate(p.date)}</p><div class="body">${esc(p.body)}</div>`;
    dlg.showModal();
  });
  $('#closeRead').onclick = () => dlg.close();
  dlg.addEventListener('click', e => { if (e.target === dlg) dlg.close(); });
}

// Dashboard
function renderDashboard() {
  const u = getUser();
  const mine = getPosts().filter(p => p.email === u.email).sort((a, b) => new Date(b.date) - new Date(a.date));
  $('#welcome').textContent = `Hello, ${u.name.split(' ')[0]}`;
  $('#stats').textContent = `You have published ${mine.length} ${mine.length === 1 ? 'story' : 'stories'}.`;
  $('#myPosts').innerHTML = mine.length ? mine.map(p => `<div class="item">
      <div><h3>${esc(p.title)}</h3><span class="meta">${esc(p.category)} · ${fmtDate(p.date)}</span></div>
      <button class="btn danger" data-del="${p.id}">Delete</button></div>`).join('')
    : `<div class="empty"><h3>No stories yet</h3><p class="muted">Your first story is one click away.</p><a class="btn" href="create-blog.html">Write a story</a></div>`;
}
if (page === 'dashboard') {
  renderDashboard();
  $('#myPosts').addEventListener('click', e => {
    const id = e.target.dataset.del; if (!id) return;
    if (!confirm('Delete this story? This cannot be undone.')) return;
    store.set('inkspace_posts', getPosts().filter(p => String(p.id) !== id));
    renderDashboard(); toast('Story deleted.');
  });
}

// Create blog
if (page === 'create') $('#blogForm').addEventListener('submit', e => {
  e.preventDefault();
  const f = new FormData(e.target), u = getUser();
  const title = f.get('title').trim(), body = f.get('body').trim();
  if (!title) return showError('Add a title for your story.');
  if (body.length < 30) return showError('Write at least 30 characters before publishing.');
  const posts = getPosts();
  posts.push({ id: Date.now(), title, category: f.get('category'), body, author: u.name, email: u.email, date: new Date().toISOString() });
  store.set('inkspace_posts', posts);
  flash('Story published.');
  location.href = 'dashboard.html';
});
